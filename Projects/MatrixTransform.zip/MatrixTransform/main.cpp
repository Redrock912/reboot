#include <iostream>
#include "Vector.h"
#include "Matrix.h"
using namespace std;

void main()
{
	Matrix3D m;
	 2*m;
}