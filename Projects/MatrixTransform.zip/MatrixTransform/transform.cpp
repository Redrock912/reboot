//#include "Matrix.h"
//#include "Vector.h"
//
//// rotate about X-axis 
//Matrix4D RotateX(float theta)
//{
//
//}
//
//Matrix4D RotateY(float theta)
//{
//
//}
//
//Matrix4D RotateZ(float theta)
//{
//
//}
//
//// rotate about u-axis 
//Matrix4D Rotate(const Vector3D& u, float theta)
//{
//
//}
//
//Matrix4D Translate(float x, float y, float z)
//{
//
//}
//
//Matrix4D Scale(float x, float y, float z)
//{
//}
//
//Matrix4D ReflectX()
//{
//}
//
//Matrix4D ReflectY()
//{
//}