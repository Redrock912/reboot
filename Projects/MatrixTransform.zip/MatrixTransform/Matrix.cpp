#include "Matrix.h"

Matrix3D& Matrix3D::operator *=(const Matrix3D& m)
{
	Matrix3D temp;
	for (int i = 0; i < 3; i++)
	for (int j = 0; j < 3; j++)
	{
		temp.n[i][j] = 0;
		for (int k = 0; k < 3; k++)
			temp.n[i][j] = temp.n[i][j] + n[i][k] * n[k][j];
	}

	for (int i = 0; i < 3; i++)
	for (int j = 0; j < 3; j++)
		this->n[i][j] = temp.n[i][j];

	return (*this);
}

Matrix3D& Matrix3D::operator *=(float t)
{
	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			n[i][j] *= t;
		}
	}

	return (*this);
}

Matrix3D& Matrix3D::operator /=(float t)
{
	for (int i = 0; i < 3;i++)
	for (int j = 0; j < 3; j++){
		n[i][j] /= t;
	}

	return (*this);
}

Matrix3D& Matrix3D::SetIdentity(void)
{
	n[0][0] = n[1][1] = n[2][2] = 1.0F;
	n[0][1] = n[0][2] = n[1][0] = n[1][2] = n[2][0] = n[2][1] = 0.0F;

	return (*this);
}

Matrix3D operator *(const Matrix3D& m1, const Matrix3D& m2)
{
	Matrix3D temp;
	for (int i = 0; i < 3; i++)
	for (int j = 0; j < 3; j++)
	{
		temp.n[i][j] = 0;
		for (int k = 0; k < 3; k++)
			temp.n[i][j] = temp.n[i][j] + m1.n[i][k] * m2.n[k][j];
	}

	//temp.nomemoryfree = true

	return temp;
}


////////////////////////////////////////////////////////
Matrix3D operator *(const Matrix3D& m, float t)
{
	return (Matrix3D(m.n[0][0] * t, m.n[0][1] * t, m.n[0][2] * t,
		m.n[1][0] * t, m.n[1][1] * t, m.n[1][2] * t,
		m.n[2][0] * t, m.n[2][1] * t, m.n[2][2] * t));
}

Matrix3D operator *(float t, const Matrix3D& m)
{
	return m*t;
}

Matrix3D operator /(const Matrix3D& m, float t)
{
	float f = 1.0F / t;
	return (Matrix3D(m.n[0][0] * f, m.n[0][1] * f, m.n[0][2] * f,
		m.n[1][0] * f, m.n[1][1] * f, m.n[1][2] * f,
		m.n[2][0] * f, m.n[2][1] * f, m.n[2][2] * f));
}

Vector3D operator *(const Matrix3D& m, const Vector3D& v)
{
	return (Vector3D());
}

//////////// �� �Ʒ��κ��� ��ȯ��Ģ�� �����ȵǱ� ������ �������ҵ�////
Vector3D operator *(const Vector3D& v, const Matrix3D& m)
{
	return (Vector3D());
}

bool operator ==(const Matrix3D& m1, const Matrix3D& m2)
{
	return ((m1.n[0][0] == m2.n[0][0]) && (m1.n[0][1] == m2.n[0][1]) && (m1.n[0][2] == m2.n[0][2]) &&
		(m1.n[1][0] == m2.n[1][0]) && (m1.n[1][1] == m2.n[1][1]) && (m1.n[1][2] == m2.n[1][2]) &&
		(m1.n[2][0] == m2.n[2][0]) && (m1.n[2][1] == m2.n[2][1]) && (m1.n[2][2] == m2.n[2][2]));
}

bool operator !=(const Matrix3D& m1, const Matrix3D& m2)
{
	return ((m1.n[0][0] != m2.n[0][0]) || (m1.n[0][1] != m2.n[0][1]) || (m1.n[0][2] != m2.n[0][2])
		|| (m1.n[1][0] != m2.n[1][0]) || (m1.n[1][1] != m2.n[1][1]) || (m1.n[1][2] != m2.n[1][2])
		|| (m1.n[2][0] != m2.n[2][0]) || (m1.n[2][1] != m2.n[2][1]) || (m1.n[2][2] != m2.n[2][2]));
}

float Determinant(const Matrix3D& m)
{
	m.n[0][0];
	return 1;
}

Matrix3D Inverse(const Matrix3D& m)
{
	
	return m;
}

Matrix3D Adjugate(const Matrix3D& m)
{
	return m;
}

Matrix3D Transpose(const Matrix3D& m)
{
	return m;
}

Matrix4D& Matrix4D::operator =(const Matrix3D& m)
{
	n[0][0] = m[0][0];
	n[0][1] = m[0][1];
	n[0][2] = m[0][2];
	n[1][0] = m[1][0];
	n[1][1] = m[1][1];
	n[1][2] = m[1][2];
	n[2][0] = m[2][0];
	n[2][1] = m[2][1];
	n[2][2] = m[2][2];

	n[0][3] = n[1][3] = n[2][3] = n[3][0] = n[3][1] = n[3][2] = 0.0F;
	n[3][3] = 1.0F;

	return (*this);
}

Matrix4D& Matrix4D::operator *=(const Matrix4D& m)
{
	return m*m;
}

Matrix4D& Matrix4D::SetIdentity(void)
{
	n[0][0] = n[1][1] = n[2][2] = n[3][3] = 1.0F;
	n[1][0] = n[2][0] = n[3][0] = n[0][1] = n[2][1] = n[3][1] = n[0][2] = n[1][2] = n[3][2] = n[0][3] = n[1][3] = n[2][3] = 0.0F;
	return (*this);
}

Matrix4D operator *(const Matrix4D& m1, const Matrix4D& m2)
{
	return m1;
}

Vector4D operator *(const Matrix4D& m, const Vector4D& v)
{
	return m*v;
}

Vector4D operator *(const Vector4D& v, const Matrix4D& m)
{
	return m*v;
}

bool operator ==(const Matrix4D& m1, const Matrix4D& m2)
{
	return ((m1.n[0][0] == m2.n[0][0]) && (m1.n[0][1] == m2.n[0][1]) && (m1.n[0][2] == m2.n[0][2]) && (m1.n[0][3] == m2.n[0][3]) && (m1.n[1][0] == m2.n[1][0]) && (m1.n[1][1] == m2.n[1][1]) && (m1.n[1][2] == m2.n[1][2]) && (m1.n[1][3] == m2.n[1][3]) && (m1.n[2][0] == m2.n[2][0]) && (m1.n[2][1] == m2.n[2][1]) && (m1.n[2][2] == m2.n[2][2]) && (m1.n[2][3] == m2.n[2][3]) && (m1.n[3][0] == m2.n[3][0]) && (m1.n[3][1] == m2.n[3][1]) && (m1.n[3][2] == m2.n[3][2]) && (m1.n[3][3] == m2.n[3][3]));
}

bool operator !=(const Matrix4D& m1, const Matrix4D& m2)
{
	return ((m1.n[0][0] != m2.n[0][0]) || (m1.n[0][1] != m2.n[0][1]) || (m1.n[0][2] != m2.n[0][2]) || (m1.n[0][3] != m2.n[0][3]) || (m1.n[1][0] != m2.n[1][0]) || (m1.n[1][1] != m2.n[1][1]) || (m1.n[1][2] != m2.n[1][2]) || (m1.n[1][3] != m2.n[1][3]) || (m1.n[2][0] != m2.n[2][0]) || (m1.n[2][1] != m2.n[2][1]) || (m1.n[2][2] != m2.n[2][2]) || (m1.n[2][3] != m2.n[2][3]) || (m1.n[3][0] != m2.n[3][0]) || (m1.n[3][1] != m2.n[3][1]) || (m1.n[3][2] != m2.n[3][2]) || (m1.n[3][3] != m2.n[3][3]));
}


float Determinant(const Matrix4D& m)
{
	return 1;
}
Matrix4D Inverse(const Matrix4D& m)
{
	return m;
}
Matrix4D Adjugate(const Matrix4D& m)
{
	return m;
}
Matrix4D Transpose(const Matrix4D& m)
{
	return m;
}






